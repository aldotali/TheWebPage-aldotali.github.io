import cs101.sosgame.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * Program name: SOSCanvas  
 * Description: Creates a panel which draws a table from SOS
 * @author Aldo Tali 21500097
 * version 1.00, 2016/04/05
 * */



public class SOSCanvas extends JPanel
{
    //constants
    private final int CELL = 50;
    private final int STRING = CELL/2;
    private final int START = 0;
    
    //properties
    private SOS reference;
    
    //constructor
    public SOSCanvas (SOS reference)
    {
        this.reference = reference;
        setPreferredSize(new Dimension(CELL*reference.getDimension()+STRING,CELL*reference.getDimension()+STRING));
        //setPreferredSize(new Dimension(CELL*reference.getDimension(),CELL*reference.getDimension()));
    }
    
    public void restart(SOS reference)
    {
        this.reference = reference;
        //setPreferredSize(new Dimension(CELL,CELL));
        setPreferredSize(new Dimension(CELL*reference.getDimension()+STRING,CELL*reference.getDimension()+STRING));
    }
    
    //draws a grid
    @Override public void paintComponent(Graphics g)
    {
        int size = reference.getDimension();
        
        for( int i = START; i <= size*CELL; i+=CELL)
        {
            g.drawLine ( START,i,size*CELL,i );
            g.drawLine ( i,START,i,size*CELL );
        }
        for ( int j = 0; j < size; j++)
        {
            for (int k = 0 ; k < size; k++)
            {
                g.drawString ( reference.getCellContents( j , k) + "" , k*CELL + STRING,j*CELL +STRING  );
            }
        }
        
    }
    
    
}
