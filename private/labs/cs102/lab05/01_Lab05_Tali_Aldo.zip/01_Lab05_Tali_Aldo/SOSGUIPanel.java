import cs101.sosgame.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * Program name: SOSGUIPanel  
 * Description: Creates a panel for the game which includes the SOSCanvas panel
 * @author Aldo Tali 21500097
 * version 1.00, 2016/04/05
 * */


public class SOSGUIPanel extends JPanel
{
    //constants
    private final int WIDTH = 400;
    private final int HEIGHT = 400;
    private int CELL = 50;
    private int STRING = CELL/2;
    
    //properties
    SOSCanvas table;
    SOS reference;
    JRadioButton sButton;
    JRadioButton oButton;
    JLabel player1;
    JLabel player2;
    int score1;
    int score2;
    char letter;
    int dimension;
    String name1;
    String name2;
    
    //constructor
    public SOSGUIPanel (SOS reference, String name1, String name2)
    {
        //initialize the properties
        this.reference = reference;
        JPanel dummy = new JPanel();
        table = new SOSCanvas ( reference );
        letter = 's';
        dimension = reference.getDimension();
        this.name1 = name1;
        this.name2 = name2;
        //setLayout(new BorderLayout());
        score1 = reference.getPlayerScore1();
        score2 = reference.getPlayerScore2();
        player1 = new JLabel(name1 + ": " + score1+ "  ");
        player2 = new JLabel(name2 + ": " + score2);
        
        //remove transparent
        player1.setOpaque(true);
        player2.setOpaque(true);
        setPreferredSize(new Dimension(HEIGHT,WIDTH));
        
        setLayout(new BorderLayout());
        
        //create the radio buttons
        sButton = new JRadioButton("S");
        sButton.setActionCommand("S");
        sButton.setSelected(true);
        
        oButton = new JRadioButton("O");
        oButton.setActionCommand("O");
        
        //create button group for radio buttons
        ButtonGroup group = new ButtonGroup();
        group.add(sButton);
        group.add(oButton);
        sButton.setOpaque(true);
        oButton.setOpaque(true);
        sButton.setBackground(Color.cyan);
        oButton.setBackground(Color.cyan);
        setBackground(Color.cyan);
        
        JRadioButtonListener listener = new JRadioButtonListener();
        sButton.addActionListener(listener);
        oButton.addActionListener(listener);
        //dummy.setLayout(new BorderLayout());
       
        dummy.setBackground(Color.cyan);
        //arrange them in the panel
        dummy.add(player1,BorderLayout.WEST);
        dummy.add(sButton,BorderLayout.CENTER);
        dummy.add(oButton,BorderLayout.CENTER);
        dummy.add(player2,BorderLayout.EAST);
        //add(new JLabel("This is spartaaa!"),BorderLayout.NORTH);
        
        add(table,BorderLayout.CENTER);
        add(dummy,BorderLayout.SOUTH);
        
        table.addMouseListener(new CanvasListener());
    }
    
    //responds to the radio buttons
    private class JRadioButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            if (event.getSource() == sButton)
            {
                letter = 's';
            }
            else if (event.getSource() == oButton)
            {
                letter = 'o';
            }
        }
    }
    
    
    
    private class CanvasListener implements MouseListener
    {
        //properties 
        int x;
        int y;
        public void mouseClicked(MouseEvent event)
        {
             
            x = event.getX();
            y = event.getY();
 
            //get the box indexes for the coordinate
            x = x/CELL;
            y = y/CELL;
 
            reference.play(letter,y + 1 ,x +1);
            //table.repaint();
            repaint();
            
            //check if it is player turn 1
            if (reference.getTurn() == 1)
            {
                score1 = reference.getPlayerScore1(); 
                player1.setText(name1 + ": " + score1+ "  ");
                player1.setBackground(Color.green);
                player2.setBackground(Color.red);
            }
            
            //check if it is the turn of player 2
            else if (reference.getTurn() == 2)
            {
                score2 = reference.getPlayerScore2();
                player2.setText(name2 + ": " + score2 + "  ");
                player2.setBackground(Color.green);
                player1.setBackground(Color.red);
            }
           
                 
            //check if game is lost
            if (reference.isGameOver())
            {
                int again; 
                String winner;
                
                //display the winner
                if (reference.getPlayerScore1() > reference.getPlayerScore2())
                    winner = "The winner is: " + name1;
                else if (reference.getPlayerScore2() > reference.getPlayerScore1())
                    winner = "The winner is: " + name2;
                else
                    winner = "It is a draw! ";
                
                again = JOptionPane.showConfirmDialog (null, winner + "\nDo Another?");
                
                //start the game again
                if (again == JOptionPane.YES_OPTION)
                {
                    score1 = 0;
                    score2 = 0;
         
                    SOS dummy = new SOS(dimension);
                    table.restart(dummy);
                    reference = dummy;
                    player1.setText(name1 + ": " + score1+ "  ");
                    player2.setText(name2 + ": " + score2+ "  ");
                    //new SOSGUIPanel(dummy, name1, name2);
                    repaint();
                }
            }
            
        }

        public void mouseExited(MouseEvent event) {};
        public void mouseReleased(MouseEvent event) {};
        public void mouseEntered(MouseEvent event) {};
        public void mousePressed(MouseEvent event) {};
    }
    

}