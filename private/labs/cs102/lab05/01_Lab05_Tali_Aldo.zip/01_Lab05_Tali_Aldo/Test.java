import cs101.sosgame.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.Timer;


/**
 * Program name: Test  
 * Description: Tests the game itself
 * @author Aldo Tali 21500097
 * version 1.00, 2016/04/05
 * */


public class Test
{
    public static void main (String[] args)
    {
        SOS test; 
        SOSGUIPanel tester;
  
        test = new SOS( 5);
        tester = new SOSGUIPanel(test, "aldo","bedri"); 
        
        JFrame frame = new JFrame("This is SPARTAAAAAA!");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.getContentPane().add(tester);
        
        frame.pack();
        frame.setVisible(true);
    }
}