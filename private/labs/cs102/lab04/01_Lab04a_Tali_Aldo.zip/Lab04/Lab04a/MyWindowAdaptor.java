import java.awt.event.*;

// MyWindowAdaptor - this is not actually needed since Java provides WindowAdaptor!
// David Davenport

//public class MyWindowAdaptor implements WindowListener
//{
// public void windowClosing(WindowEvent e) {}
// public void windowActivated(WindowEvent e) {}
// public void windowClosed(WindowEvent e)  {}
// public void windowDeactivated(WindowEvent e) {}
// public void windowDeiconified(WindowEvent e) {}
// public void windowIconified(WindowEvent e) {}
// public void windowOpened(WindowEvent e) {}
//}