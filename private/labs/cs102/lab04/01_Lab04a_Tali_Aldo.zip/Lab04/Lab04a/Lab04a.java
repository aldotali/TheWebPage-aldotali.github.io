/**
 * Program name: Lab04a 
 * Description: creates an instance to a simple game
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/15
 * */

import java.util.Scanner;
import java.awt.*;


public class Lab04a
{
    public static void main( String[] args)
 {
     Scanner scan = new Scanner( System.in);

     System.out.println( "Start of GUI1\n");

     Frame  test;
     test = new MyFrame();



  System.out.println( "\nEnd of GUI1\n" );
 }

} 