/**
 * Program name: MyActionListener 
 * Description: Create class close the windo on pushing cllose button
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/15
 * */

import java.awt.event.*;

public class MyWindowListener extends WindowAdapter
{
    @Override
    public void windowClosing(WindowEvent e)
    {
        System.exit(0);
    }
}

