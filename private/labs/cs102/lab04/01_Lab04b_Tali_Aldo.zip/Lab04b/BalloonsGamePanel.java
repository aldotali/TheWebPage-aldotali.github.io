/**
 * Program name: Lab04 b part
 * Description: Creates a panel to draw every balloon
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/22
 * */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import shapes.*;
import java.util.*;
import javax.swing.Timer;

public class BalloonsGamePanel extends JPanel
{
    //contants
    private static final int MILLISECONDS = 100;
    private static final int TIME_PERIOD = 20;
    private static final int WIDTH = 800;
    private static final int HEIGHT = 800;
    private static final int NR_OF_BALLOONS = 25;
    private static final int MIN_BALLOONS = 15;
    
    //properties
    private ShapeContainer balloons;
    private Timer timer;
    private int time;
    private int points;
    JLabel label;
    
    //constructor
    public BalloonsGamePanel()
    {
        setBackground(Color.cyan);
        setLayout(new FlowLayout());
        points =0;
        label = new JLabel("Points : "+ points + "  ");
        add (label);
        initialize();
    }
    
    //initializes a new game
    public void initialize()
    {
        balloons = new ShapeContainer(); 
        addMouseListener (new PointsListener());
        
        for ( int i = 0; i < NR_OF_BALLOONS; i++)
        {
            balloons.add(new Balloon());
        }
        
        timer = new Timer(MILLISECONDS, new TimerListener());
        this.setPreferredSize(new Dimension(WIDTH,HEIGHT));
        time = 0;
        timer.start();
    }
    
    //overrides the paint component to draw balloons
    @Override public void paintComponent ( Graphics page)
    {
        super.paintComponent (page);
        Balloon b;
        Iterator i = balloons.iterator();
        
        //draw each balloon
        while ((i.hasNext()))
        {
            b = (Balloon)((i.next()));
            b.draw(page);
        }
    }
    
    //inner class for the time listener
    private class TimerListener implements ActionListener
    {
        //whenever an action happens excecute
        public void actionPerformed ( ActionEvent event)
        {
            //properties
            Balloon b;
            Iterator i ;
            
            balloons.removeSelected();
            i = balloons.iterator();
            
            balloons.removeSelected();
            
            //grow the circles
            while (i.hasNext())
            {
                b = (Balloon)(i.next());
                b.grow();
                repaint();  
            }
            
            
            time = time + 1;
            
            //add balloons whenever they lower to MIN_BALLOONS
            if (balloons.size() < MIN_BALLOONS)
            {
                b = new Balloon();
                balloons.add(b);
            }
            
            //check if the limit time passes
            if (time > TIME_PERIOD*1000/MILLISECONDS)
            {
                int again;
                timer.stop();
                
                JOptionPane.showMessageDialog (null, "The game is over");
                again = JOptionPane.showConfirmDialog (null, "Do Another?");
                
                //play another game
                if (again == JOptionPane.YES_OPTION)
                {
                    points = 0;
                    label .setText("Points : "+ points + "  ");
                    initialize();
                }
            }
            repaint();
        }
        
    }
    
    //gets the mouse event
    public class PointsListener implements MouseListener
    {
        @Override public void mousePressed (MouseEvent event)
        {
            int x ;
            int y;
            int dummy; 
            
            x = event.getX();
            y = event.getY();
            dummy = balloons.selectAll(x,y);
            
            //check if more than two are pressed
            if (dummy > 1)
            {
                points = points + dummy;
            }
            
            label.setText("Points : "+ points + "  ");
//            System.out.println(dummy);
//            System.out.println(x+ "   " + y);
            repaint();
        }
        public void mouseClicked (MouseEvent event) {}
        public void mouseReleased (MouseEvent event) {}
        public void mouseEntered (MouseEvent event) {}
        public void mouseExited (MouseEvent event) {} 
    }
}
