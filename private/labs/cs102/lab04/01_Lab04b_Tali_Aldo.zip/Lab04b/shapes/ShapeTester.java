package shapes;

///**
// * Program name: Lab03a (2)
// * Description: Createsa Tester for the shapes
// * @author Aldo Tali 21500097
// * version 1.00, 2016/03/01
// * */
//
//import java.util.Scanner;
//
//public class ShapeTester
//{
//    public static void main (String[] args)
//    {
//        Scanner scan = new Scanner (System.in);
//        
//        //properties
//        ShapeContainer shapeContainer;
//        int            input;
//        int            side1;
//        int            side2;
//        double         area;
//        
//        shapeContainer = new ShapeContainer();
//        
//        //repeat until user quits
//        do 
//        {
//            System.out.println("Select an option: ");
//            System.out.println("1. Add a rectangle ");
//            System.out.println("2. Add a square ");
//            System.out.println("3. Add a circle ");
//            System.out.println("4. Compute area ");
//            System.out.println("5. Print shapes ");
//            System.out.println("6. Find the first shape ");
//            System.out.println("7. Remove all selected ");
//            System.out.println("8. Quit ");
//            
//            input = scan.nextInt();
//            
//            if (input == 1)
//            {
//                System.out.println("Enter the sides: ");
//                side1 = scan.nextInt();
//                side2 = scan.nextInt();
//                shapeContainer.add(new Rectangle(side1, side2));
//            }
//            
//            else if (input == 2)
//            {
//                System.out.println("Enter the side ");
//                {
//                    side1 = scan.nextInt();
//                    shapeContainer.add(new Square(side1));
//                }
//            }
//            
//            else if (input == 3)
//            {
//                System.out.println("Enter the radius ");
//                {
//                    side1 = scan.nextInt();
//                    shapeContainer.add(new Circle(side1));
//                }
//            }
//            
//            else if (input == 4)
//            {
//                shapeContainer.getArea();
//            }
//            
//            else if (input == 5)
//            {
//                System.out.println(shapeContainer.toString());
//            }
//            
//            else if (input == 6)
//            {
//                System.out.println("Please enter the locations x and y ");
//                side1 = scan.nextInt();
//                side2 = scan.nextInt();
//                shapeContainer.findFirst(side1, side2);
//            }
//            else if (input == 7)
//            {
//                shapeContainer.removeSelected();
//            }
//        }while (input != 8);
//    }
//}