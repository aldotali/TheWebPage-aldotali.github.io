package shapes;

/**
 * Program name: Lab03a (1)
 * Description: Creates Square class of the hiearchy of shapes
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

public class Square extends Rectangle
{
    //properties
    int side;
    
    //constructor
    public Square (int side)
    {
        super(side, side);
        this.side = side;
    }
    
    //returns the String representation
    public String toString()
    {
        return ("The area of the square with side : " + side + " is : " + getArea() 
                    + "\n Is square selected? " + getSelected());
    }
}