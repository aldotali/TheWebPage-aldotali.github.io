/**
 * Program name: Lab04 b part
 * Description: Creates a frame to a simple game
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/22
 * */

import java.util.Scanner;
import javax.swing.JFrame;
import java.awt.*;

public class Lab04b
{
    
    public static void main (String[] args)
    {
        JFrame frame = new JFrame( "Lab04");
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        
        frame.getContentPane().add( new BalloonsGamePanel());
 
        frame.setLayout(new FlowLayout());

        frame.pack();
        frame.setVisible(true);
    }
}
