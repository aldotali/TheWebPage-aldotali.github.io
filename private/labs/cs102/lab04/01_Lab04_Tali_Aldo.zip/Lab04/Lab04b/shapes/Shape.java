package shapes;

/**
 * Program name: Lab03a (1)
 * Description: Creates the abstract class Shape to include all shapes
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

public abstract class Shape implements Locatable
{
    //properties
    int x;
    int y;
    
    //returns the area of the shape
    public abstract double getArea();
    
    //returns the String representation
    public abstract String toString();
    
    //Sets the location of the shape
    public void setLocation(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    
    //returns the x coordinate of the location of the shape
    public int getX()
    {
        return x;
    }
    
    //returns the y coordinate of the location of the shape
    public int getY()
    {
        return y;
    }
    
    
}