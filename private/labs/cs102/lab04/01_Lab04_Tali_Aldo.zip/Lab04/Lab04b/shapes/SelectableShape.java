package shapes;

/**
 * Program name: Lab03a (1)
 * Description: Creates the abstract class Shape to include all shapes
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

public abstract class SelectableShape extends Shape implements Selectable
{  
  private boolean selected;
  
  // returns if selected
  public boolean getSelected()
  {
    return selected;
  }
  
  // returns if able to set selection status
  public void setSelected (boolean s)
  {
    selected = s;
  }
}