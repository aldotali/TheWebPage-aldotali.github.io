package shapes;

/**
 * Program name: Lab03a (1)
 * Description: Creates Circle class of the hiearchy of shapes
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

import java.lang.Math;
import javax.swing.JApplet;
import java.awt.*;

public class Circle extends SelectableShape implements Selectable
{
    //properties
    int radius;
    boolean selected;
    
    //contructor
    public Circle  (int radius)
    {
        this.radius  = radius;
        selected = false;
    }
    
    //returns the area
    public double getArea()
    {
        return (double) (Math.PI *Math.pow(radius,2));
    }
    
    //returns String representation
    public String toString()
    {
        return ("The area of the circle with radius : " + radius + " is : " + getArea() + "\n" 
                    + "Is the circle selected? " + getSelected());
    }
    
    //checks if the coordinates are in the circle
    public Shape shapecontains( int x, int y)
    {
        double  length;
        double radius1 = (double) radius;

        length = (double) Math.sqrt(Math.pow((this.getX() - x),2) + Math.pow((this.getY() - y ),2));
        if (length <= radius1)
        {
            return this;
        }
        return null;
    }
    
    //changes the selected state of the circle
    public void setSelected(boolean s)
    {
        selected = s;
    }
    
    //returns the selected state of the circle
    public boolean getSelected()
    {
        return selected;
    }
    
    public int getR()
    {
        return radius;
    }
    
    public void setR( int a)
    {
        radius = a;
    }
    
    
}