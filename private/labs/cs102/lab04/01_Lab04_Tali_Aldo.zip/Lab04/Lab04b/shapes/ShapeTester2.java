package shapes;

/**
 * Program name: Lab03a (2)
 * Description: Createsa Tester for the shapes
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

import java.util.Scanner;
//import shapes.*;
public class ShapeTester2
{
    public static void main (String[] args)
    {
        Scanner scan = new Scanner (System.in);
        
        //properties
        ShapeContainer shapeContainer;
        int            input;
        int            input2;
        int            side1;
        int            side2;
        double         area;
        Shape          temp;
        
        shapeContainer = new ShapeContainer();
        temp = null;
        
        //repeat until user quits
        do 
        {
            System.out.println("Select an option: ");
            System.out.println("1. Create a new container ");
            System.out.println("2. Add a shape ");
            System.out.println("3. Compute area ");
            System.out.println("4. Print shapes ");
            System.out.println("5. Find the first shape ");
            System.out.println("6. Remove all selected ");
            System.out.println("7. Quit ");
            
            input = scan.nextInt();
            
            if (input == 1)
            {
                shapeContainer = new ShapeContainer();;
            }
            
            else if (input == 2)
            {
                if (shapeContainer == null)
                {
                    System.out.println("Sorry a container is not yet created ");
                }
                else
                {
                    do
                    {
                        System.out.println("1. Add a circle ");
                        System.out.println("2. Add a rectangle ");
                        System.out.println("3. Add a square ");
                        System.out.println("4. Go to the main menu ");
                        
                        input2 = scan.nextInt();
                        
                        if (input2 == 1)
                        {
                            System.out.println("Enter the radius ");
                            side1 = scan.nextInt();
                            shapeContainer.add(new Circle(side1));
                            System.out.println("Enter the locations x and y ");
                            side1 = scan.nextInt();
                            side2 = scan.nextInt();
                            (shapeContainer.getV()).setLocation(side1,side2);
                        }
                        
                        if (input2 == 2)
                        {
                            System.out.println("Enter the sides ");
                            side1 = scan.nextInt();
                            side2 = scan.nextInt();
                            shapeContainer.add(new Rectangle(side1,side2));
                            System.out.println("Enter the locations x and y ");
                            side1 = scan.nextInt();
                            side2 = scan.nextInt();
                            (shapeContainer.getV()).setLocation(side1,side2);
                        }
                        
                        if (input2 == 3)
                        {
                            System.out.println("Enter the side ");
                            side1 = scan.nextInt();
                            shapeContainer.add(new Square(side1));
                            System.out.println("Enter the locations x and y ");
                            side1 = scan.nextInt();
                            side2 = scan.nextInt();
                            (shapeContainer.getV()).setLocation(side1,side2);
                        }
                        
                    }while (input2 != 4);
                  
                }
            }
            
            
            else if (input == 3)
            {
                shapeContainer.getArea();
            }
            
            else if (input == 4)
            {
                System.out.println(shapeContainer.toString());
            }
            
            else if (input == 5)
            {
                System.out.println("Please enter the locations x and y ");
                side1 = scan.nextInt();
                side2 = scan.nextInt();
                temp = shapeContainer.findFirst(side1, side2);
                if (temp == null)
                System.out.println("Sorry the locations are out of the shape");
                else
                System.out.println("The first shape is : \n " + temp.toString());
            }
            else if (input == 6)
            {
                shapeContainer.removeSelected();
            }
        }while (input != 7);
    }
}