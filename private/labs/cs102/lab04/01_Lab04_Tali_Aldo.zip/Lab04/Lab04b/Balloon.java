/**
 * Program name: Lab04 b part
 * Description: Creates a Ballon class  to create a drawable circle
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/22
 * */

import shapes.*;
import javax.swing.JApplet;
import java.awt.*;

public class Balloon extends Circle implements Drawable
{
    //constants
    private static final int WIDTH = 800;
    private static final int HEIGHT = 800;
    private static final int MAX_SIZE = 100;
    private static final int DEFAULT_RADIUS = 25;
    //properties
    int radius;
    
    //constructor
    public Balloon()
    {
        super(DEFAULT_RADIUS);
        radius=DEFAULT_RADIUS;
        int x ; 
        int y;
        x = (int) (Math.random() * WIDTH) ;
        y = (int) (Math.random() * HEIGHT);
        setLocation(x,y);
    }

    //overrides the draw method
    @Override public void draw (Graphics page)
    {  
        radius = this.getR();
        
        //draw a circle
        page.drawOval (getX()-getR(),getY()-getR(), radius*2, radius*2);

    }
    
    //increases the size of the radius
    public void grow()
    {
       this.setR(this.getR() + 1);
       
       //checks if circle becomes too big
       if ( this.getR() > MAX_SIZE)
       {
           this.setSelected(true);
       }

    }
}