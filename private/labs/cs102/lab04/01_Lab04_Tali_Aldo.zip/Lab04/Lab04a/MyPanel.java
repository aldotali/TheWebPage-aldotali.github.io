///**
// * Program name: MyActionListener 
// * Description: Creates the panel in the frame
// * @author Aldo Tali 21500097
// * version 1.00, 2016/03/15
// * */
//
//import java.awt.*;
//import java.awt.event.*;
//
//public class MyPanel extends Panel implements ActionListener
//{
//    //constants
//    final int NO_OF_BUTTONS = 25;
//    final int NO_OF_PANELS = 5;
//    final int NO_OF_BUTTON_PER_PANEL = 5;
//    
//    //properties
//    Button[] b;
//    Button dummy;
//    Button restart;
//    int noOfTries;
//    Label statusLabel;
//    
//    //contructor
//    public MyPanel()
//    {
//        //properties
//        Panel theWholePanel;
//        GridLayout matrix;
//        Panel[] a; 
//       
//        
//        //initialization
//        matrix = new GridLayout(NO_OF_PANELS + 2 ,0);
//        b = new Button[NO_OF_BUTTONS];
//        a = new Panel[NO_OF_PANELS];
//        noOfTries = 0;
//        theWholePanel = new Panel();
//        //setLayout ( new BorderLayout() );
//        statusLabel = new Label("Number of incorrect tries is: " + getNoOfTries());
//        theWholePanel.add(statusLabel);
//        restart = new Button ("Start from the beginning");
//        restart.addActionListener( this);
//        
//        //create the buttons
//        for (int i = 0; i < NO_OF_PANELS; i++)
//        {
//            a[i] = new Panel(); 
//            
//            //add buttons for each panel
//            for (int j = i*NO_OF_BUTTON_PER_PANEL; j < i*NO_OF_BUTTON_PER_PANEL +NO_OF_BUTTON_PER_PANEL; j++)
//            {
//                b[j] = new Button ("Press me!");
//                a[i].add(b[j]);
//                b[j].addActionListener( this);
//            }
//            theWholePanel.add(a[i]);
//        }
//        
//        theWholePanel.add(restart);
//        theWholePanel.setLayout(matrix);
//        add(theWholePanel);
//        chooseSecret();
//    }
//    
//    //determines the secretword
//    public void chooseSecret ()
//    {
//        //properties
//        int random;
//        
//        random = (int) (Math.random()*NO_OF_BUTTONS);
//        dummy = b[random];
//        System.out.println("random is" + random);
//    }
//    
//    //return number of tries
//    public int getNoOfTries()
//    {
//        return noOfTries;
//    }
//    
//    //determines what to do when action occurs
//    public void actionPerformed( ActionEvent e)
//    {
//        //properties
//        Button disable;
//        
//        //check if user won
//        System.out.println("noOfTries is " + noOfTries);
//        if ( e.getSource() == dummy)
//        {
//            System.out.println( "Wow you found it in " + getNoOfTries() + " tries");
//            statusLabel.setText("Wow you found it in " + (getNoOfTries() +1) + " tries");
//            restart.setEnabled(true);
//            
//        }
//        
//        //disable the used button
//        disable  =(Button) e.getSource();
//        disable.setEnabled(false);
//        
//        //check if user restarts
//        if( e.getSource() == restart )
//        {
//            noOfTries = 0;
//            chooseSecret();
//            statusLabel.setText("Wow you found it in " + getNoOfTries() + " tries");
//            System.out.println("The price button is now changed");
//            
//            //reenable all buttons
//            for (int i = 0; i < NO_OF_BUTTONS; i++)
//            {
//                b[i].setEnabled(true);
//            }
//        }
//        
//        //increment number of tries
//        else 
//        {
//            noOfTries++;
//            statusLabel.setText("Number of incorrect tries is: " + getNoOfTries());
//        }
//    }
//    
//    public void paint( Graphics g )
//    {
//        //g.drawString( "This will work!", 200, 200);
//        // System.out.println( "Paint called");
//    }
//}