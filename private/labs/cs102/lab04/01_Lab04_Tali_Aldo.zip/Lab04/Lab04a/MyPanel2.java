/**
 * Program name: MyActionListener 
 * Description: Creates the panel in the frame
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/15
 * */

import java.awt.*;
import java.awt.event.*;

public class MyPanel2 extends Panel implements ActionListener
{
    //constantS
    final int ROW = 5;
    final int COL = 5;
    final int NO_OF_BUTTONS = ROW*COL;
    
    
    //properties
    Button[] b;
    Button dummy;
    Button restart;
    int noOfTries;
    Label statusLabel;
 
        
    //contructor
    public MyPanel2()
    {
        //properties
        Panel theWholePanel;
        Panel label;
        GridLayout matrix;
          
        //initialization
        theWholePanel = new Panel();
        matrix = new GridLayout(ROW,COL);
        theWholePanel.setLayout ( matrix );
        b = new Button[NO_OF_BUTTONS];
        noOfTries = 0;
        setLayout(new BorderLayout());
        
        statusLabel = new Label("Number of incorrect tries is: " + getNoOfTries());
        label = new Panel();
        label.add(statusLabel, BorderLayout.NORTH);
        restart = new Button ("Start from the beginning");
        restart.addActionListener( this);
        
        //create the buttons
        for (int i = 0; i < NO_OF_BUTTONS; i++)
        {
                b[i] = new Button ("Press me!");
                b[i].setBackground(Color.YELLOW);
                theWholePanel.add(b[i]);
                b[i].addActionListener( this);
        }
        
        //add the panels on the frame
        add(label,BorderLayout.NORTH);
        add(theWholePanel,BorderLayout.CENTER);
        add(restart,BorderLayout.SOUTH);
        chooseSecret();
    }
    
    //determines the secretword
    public void chooseSecret ()
    {
        //properties
        int random;
        
        random = (int) (Math.random()*NO_OF_BUTTONS);
        dummy = b[random];
        System.out.println("random is" + random);
    }
    
    //return number of tries
    public int getNoOfTries()
    {
        return noOfTries;
    }
    
    //determines what to do when action occurs
    public void actionPerformed( ActionEvent e)
    {
        //properties
        Button disable;
        
        //check if user won
        System.out.println("noOfTries is " + noOfTries);
        if ( e.getSource() == dummy)
        {
            System.out.println( "Wow you found it in " + getNoOfTries() + " tries");
            statusLabel.setText("Wow you found it in " + (getNoOfTries() +1) + " tries");
            restart.setEnabled(true);
            
            //disable buttons when game finishes
            for (int i = 0; i < NO_OF_BUTTONS; i++)
            {
                b[i].setEnabled(false);
            }
            
        }
        
        //disable the used button
        disable  =(Button) e.getSource();
        disable.setEnabled(false);
        
        //check if user restarts
        if( e.getSource() == restart )
        {
            noOfTries = 0;
            chooseSecret();
            statusLabel.setText("Wow you found it in " + getNoOfTries() + " tries");
            System.out.println("The price button is now changed");
            
            //reenable all buttons
            for (int i = 0; i < NO_OF_BUTTONS; i++)
            {
                b[i].setEnabled(true);
            }
        }
        
        //increment number of tries
        else 
        {
            noOfTries++;
            statusLabel.setText("Number of incorrect tries is: " + getNoOfTries());
        }
    }
    
    public void paint( Graphics g )
    {
        //g.drawString( "This will work!", 200, 200);
        // System.out.println( "Paint called");
    }
}