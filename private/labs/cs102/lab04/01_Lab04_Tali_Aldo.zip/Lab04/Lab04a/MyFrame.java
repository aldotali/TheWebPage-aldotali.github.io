/**
 * Program name: MyActionListener 
 * Description: Create a frame to a simple game
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/15
 * */

import java.awt.*;
import java.awt.event.*;

public class MyFrame extends Frame
{
    public MyFrame ()
    {
        //set up the w�ndow
        setBounds( 400,400,500,300);
        setBackground( Color.green);
        
        addWindowListener( new MyWindowListener() );
        add (new MyPanel2());
        addWindowListener( new MyWindowListener() );
        setVisible( true);
        //setResizable( false);
    }
}
    