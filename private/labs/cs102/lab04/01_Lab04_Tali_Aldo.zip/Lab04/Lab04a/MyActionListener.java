/**
 * Program name: MyActionListener 
 * Description: Create class to get the action
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/15
 * */

import java.awt.event.*;

public class MyActionListener implements ActionListener
{
    public void actionPerformed( ActionEvent x)
    {
        
    }
}