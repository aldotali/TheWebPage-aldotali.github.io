import cs1.SimpleURLReader;
import java.util.Scanner;

/**
 * Program name: MySimpleURLReader
 * Description: extends  SimpleURLReader 
 * @author Aldo Tali 21500097
 * version 1.00, 2016/02/21
 * */

public class MySimpleURLReader extends SimpleURLReader
{
    String url;
    
    //constructor
    public MySimpleURLReader (String url)
    {
        super (url);
        this.url = url;
    }
    
    // returns string representation of url
    public String getURL()
    {
        return url;
    }
    
    //return the name of the file
    public String getName()
    {
        int index;
        index = -1;
        
        //itirrates until it finds the last '/' charcacher
        for (int i = getURL().length() - 1; i >= 0; i--)
        {
            if (getURL().charAt(i) == '/')
            {
                index = i;
                i = -1;
            }
        }
        
        return getURL().substring(index + 1,getURL().length());
    }
    
    //overides getPageContents() method
    //@OVERRIDE
    @Override public String getPageContents()
    {
        String s;
        s = super.getPageContents();
        return s.substring(4,s.length());
    }
}