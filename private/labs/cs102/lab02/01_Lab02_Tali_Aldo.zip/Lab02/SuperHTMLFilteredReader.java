import cs1.SimpleURLReader;
import java.util.*;

/**
 * Program name: SuperHTMLFilteredReader
 * Description: extends  HTMLFilteredReader to filter a HTML page 
 * @author Aldo Tali 21500097
 * version 1.00, 2016/02/21
 * */

public class   SuperHTMLFilteredReader extends HTMLFilteredReader
{
    //properties
    ArrayList<String> links;
    boolean           check;
    
    //constructor
    public  SuperHTMLFilteredReader (String url)
    {
        super (url);
        links = new ArrayList<String>();
        check = true;
    }
    
    //returns the percentage increase of text with html code
    public double overheadDue()
    {
        return ((double) ((super.getUnfilteredPageContents()).length() 
                             - (super.getPageContents()).length()) /100);
    }
    
    //exctratcs the links on the page
    public void extractLinks()
    {
        //properties
        String s;
        String link;
        int current;
        
        //initialization
        current = 0;
        link = "";
        s = super.getUnfilteredPageContents();
        check = false;
        
        for (int i = 0 ; i < s.length(); i++)
        {
            current = s.indexOf("href=",i);
            if (current < 0)
            {
                i = s.length();
            }
            else
            {
                link = s.substring(current + 5, s.indexOf('"',current+6) +1 );
                //link = link.substring(5,link.length());
                i = s.indexOf('"',current+6);
                //link = link + "\"";
                links.add(link);
                link = "";
            }
        }
    }
    
    //return the list of links
    public ArrayList<String> getLinks()
    { 
      if (check)
      {
        extractLinks();
      }
      return links; 
    }
}