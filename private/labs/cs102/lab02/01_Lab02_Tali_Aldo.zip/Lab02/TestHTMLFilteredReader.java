import cs1.SimpleURLReader;
import java.util.Scanner;

/**
 * Program name: TestHTMLFilteredReader
 * Description: provides a test case for HTMLFilteredReader 
 * @author Aldo Tali 21500097
 * version 1.00, 2016/02/21
 * */

public class TestHTMLFilteredReader
{
    public static void main (String[] args)
    {
       // constants
        final String URL = "http://www.cs.bilkent.edu.tr/~david/housman.htm";
        
        //properties
        HTMLFilteredReader test;
        String             content;
        int                lineNo;
        
        
        test = new  HTMLFilteredReader (URL);
        content = test.getPageContents();
        lineNo = test.getLineCount();
        
        System.out.println("This is the content of the webpage : \n\n\n" + content +"\n");
        System.out.println("The webpage has " + lineNo + " lines.");
        System.out.println("The link is : " + test.getURL());
        System.out.println("The name is : " + test.getName());
      
    }
}