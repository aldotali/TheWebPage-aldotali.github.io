import cs1.SimpleURLReader;
import java.util.*;

/**
 * Program name: Lab02e
 * Description: provides a simple menu to store and make pages available
 * @author Aldo Tali 21500097
 * version 1.00, 2016/02/21
 * */

public class Lab02e
{
    public static void main (String[] args)
    {
        Scanner scan = new Scanner (System.in);
        
        //properties
        int                            input;
        String                         url;
        ArrayList<MySimpleURLReader>   list;
        MySimpleURLReader              dummy;
        HTMLFilteredReader             dummy1;
        
        list = new ArrayList<MySimpleURLReader>();
        
        System.out.println("Welcome to the Menu! \n\n");
        do
        {
            System.out.println(" (1) Enter the url of poem to add to collection.");
            System.out.println(" (2) List all poems in the collection.");
            System.out.println(" (3) Quit.");
            System.out.println("Please enter an option \n");
            input = scan.nextInt();
            
              
            if (input == 1)
            {
                System.out.println("Please enter the link of the poem : \n");
                url = scan.next();
                
                if (url.length()<4)
                {
                  System.out.println(" Please enter a valid link ");
                }
                else if ((url.substring(url.length()-3,url.length())).equals("txt"))
                {
                    dummy = new MySimpleURLReader(url);
                    list.add(dummy);
                }
                else if ((url.substring(url.length()-4,url.length())).equals("html")
                        || (url.substring(url.length()-3,url.length())).equals("htm"))
                {
                    dummy1 = new HTMLFilteredReader(url);
                    list.add(dummy1);
                }
                else
                {
                  System.out.println(" Please enter a valid link ");
                }
            }
            
            else if (input == 2)
            {
                System.out.println("The poems are : \n");
                
                for (int i = 0; i < list.size(); i++)
                {
                    System.out.println( i + " " + (list.get(i)).getName());
                }
                
                System.out.println("Please enter the index of a poem : \n");
                input = scan.nextInt();
                
                if (input < list.size())
                {
                    System.out.println((list.get(input)).getPageContents());
                }
                else if (input == list.size() || input == 3)
                {
                    input = 4;
                }
            }
            else if (input != 3)
            {
                System.out.println("Your selection is not valid :/");
            }
        }while(input != 3);
        
        System.out.println("Thank you for using the program");
    }
}