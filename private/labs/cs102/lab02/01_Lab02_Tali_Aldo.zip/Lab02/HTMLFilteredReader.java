import cs1.SimpleURLReader;
import java.util.Scanner;

/**
 * Program name: HTMLFilteredReader
 * Description: reads and filters an html webpage
 * @author Aldo Tali 21500097
 * version 1.00, 2016/02/21
 * */


public class  HTMLFilteredReader extends MySimpleURLReader
{
    //constructor
    public  HTMLFilteredReader (String url)
    {
        super (url);
    }
    
    //gets the contents of the html
    public String getUnfilteredPageContents()
    {
        return super.getPageContents();
    }
    
    //overrides the method by filtering the Html code
    //@OVERRIDES
    public String getPageContents()
    {
        boolean check;
        String s;
        
        s = "";
        
        for (int i = 0; i < getUnfilteredPageContents().length(); i++)
        {
            check = true;
            if (getUnfilteredPageContents().charAt(i) == '<')
            {
                for (int j = i + 1; j < getUnfilteredPageContents().length(); j++)
                {
                    if (getUnfilteredPageContents().charAt(j) == '>')
                    {
                        i = j;
                        check = false;
                        j = getUnfilteredPageContents().length();
                    }
                }
            }
            if (check)
            {
                s = s + getUnfilteredPageContents().charAt(i);
            }
        }
        return s;
    }
}