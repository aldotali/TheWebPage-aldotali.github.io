import cs1.SimpleURLReader;
import java.util.*;

/**
 * Program name: TestSuperHTMLFilteredReader
 * Description: provides a test case for SuperHTMLFilteredReader 
 * @author Aldo Tali 21500097
 * version 1.00, 2016/02/21
 * */

public class TestSuperHTMLFilteredReader
{
    public static void main (String[] args)
    {
       // constants
        final String URL = "http://www.cs.bilkent.edu.tr/~david/index.html";
        
        //properties
        SuperHTMLFilteredReader test;
        String                  content;
        double                  percentage;
        ArrayList<String>       links;
        
        
        test = new  SuperHTMLFilteredReader (URL);
        percentage = test.overheadDue();
       // test.extractLinks();
        links = test.getLinks();
        
        
        for (int i = 0; i < links.size(); i++)
        {
            System.out.println("The " + (i+1) + " link is: " + links.get(i));
        }
        System.out.println("The link is : \"" + test.getURL()+"\"");
        System.out.println("The percentage is: " + percentage + "%");
      
    }
}