import java.util.*;
import java.util.Iterator;

/**
 * Program name: IntBag class Lab03 part b
 * Description: This class creates a collection of integers
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

public class IntBag implements Iterable
{
    //constants
    public static final int Max_ELSE=100;
    
    //properties
    int[] bag;
    
    //no parameter constructor
    public IntBag()
    {   
        bag = new int[Max_ELSE + 1 ];    
        bag[0] = -1;
    }
    
    //constructor with max array length as parameter
    public IntBag(int max)
    {   
        bag = new int[max +1];
        bag[0] = -1;
    }
    
    //adds a value the collection
    public void add(int value)
    {
        //System.out.println(size());
        if (size() >= bag.length -1)
        {
            System.out.println("You are exceeding your bounds!" + "\n The last value cannot be added to the collection" );
        }
        else
        {
            bag[size() + 1] = -1;
            bag[size()] = value;
        }
    }
    
    //adds a value at a specific index    
    public void add(int index, int value)
    {
        if (index >= size() || index > size() || size() >= bag.length - 1)
        {
            System.out.println("Sorry the index is out of bound or the array is already full");
        }
        else
        {
            int size;
            int temp = bag[index];
            
            size = size();
            bag[size + 1] = -1;
            bag[index] = value;
            
            
            //shifts values continiously to the right
            for(int i = index+1; i <= size ; i++)
            {
                value = bag[i];
                bag[i] = temp;
                temp = value;
            }
        }
    }
    
    //removes a value from the collection
    public void remove(int index)
    {
        if (index >= size())
        {
            System.out.println("Sorry the index is out of bound");
        }
        else
        {
            //continiously shift values to the left
            for(int i = index; i < size() -1; i++ )
            {
                bag[i] = bag[i+1];
            }
            bag[size() -1]=-1;
        }
    }
    
    //check if the bag contains the value
    public boolean contains (int value)
    {
        for (int i = 0; i < size(); i++)
        {
            if (bag[i] == value)
            {
                return true;
            }
        }
        return false;
    }
    
    // return the String representation of the array
    public String toString()
    {
        String  s = "[";
        for (int i = 0; i < size(); i++)
        {
            s = s + bag[i] + ",";
        }
        if (s.length()==1)
            return "[]";
        else
            return (s.substring(0,s.length()-1)+ "]");
    }
    
    // return the size of the collection
    public int size()
    {
        for (int i = 0 ; i < bag.length; i++)
        {
            if (bag[i] < 0)
                return i;
        }
        return bag.length;
    }
    
    //returns the number at the specific index
    public int get(int index)
    {
        return bag[index];
    }
    
    // finds the positions where a value is repeated
    public IntBag findAll(int value)
    {
        
        IntBag locations;
        locations = new IntBag(bag.length);
        
        for (int i = 0; i < size(); i++)
        {
            if ( bag[i] == value)
            {
                locations.add(i);
            }
        }
        return locations; 
    }
    
    //returns the next integer is the collection
    public int nextInt()
    {
        return (Integer) nextInt();
    }
    
    //returns the IntBagIterator as the new iterator
    public Iterator iterator()
    {
        IntIterator i;
        
        i = new IntBagIterator(this);
        return(i );
    }
    
     //theIntBagIterator  inner class
    class IntBagIterator implements IntIterator 
    {
        //properties
        IntBag aBag;
        int index;
        
        //contructor
        public IntBagIterator (IntBag bag)
        {
            aBag = bag;
            index = -1;
        }
        
        //returns the next integer in the collection
        public int nextInt()
        {
            index++;
            return aBag.get(index);
        }
        
        //returns the next value in the collection
        public Integer next()
        {
            return nextInt();
        }
        
        //checks if there is another value in the collection
        public boolean hasNext()
        {
            return index < aBag.size() - 1;
        }
        
        
    }
}