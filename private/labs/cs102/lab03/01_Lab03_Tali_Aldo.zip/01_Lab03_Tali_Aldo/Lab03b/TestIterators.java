import java.util.Scanner;
import java.util.Iterator;


/**
 * Program name: TestIterators class Lab03 part b
 * Description: This tests the new iterators
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

public class TestIterators
{
    public static void main (String args[])
    {
        Scanner scan = new Scanner (System.in) ;
        
        //properties
        IntBag bag;
        
        //initialization
        bag = new IntBag (5);
        
        bag.add(8);
        bag.add(5);
        bag.add(14);
        bag.add(2);
        bag.add(8);
        
        Iterator i, j;
        
        i = bag.new IntBagIterator( bag);
//        System.out.println(i.next() );
//        System.out.println(i.next() );
//        System.out.println(i.next() );
//        System.out.println(i.next() );
//        System.out.println(i.next() );
        
        //prints the elements making use of iterators
        while ( i.hasNext() ) 
        {
            System.out.println( i.next() );
            
            j = bag.new IntBagIterator( bag);
            j = bag.iterator();
            
            while ( j.hasNext() )
            {
                System.out.println( "--" + j.next() );
            }
        }
        
    }
}