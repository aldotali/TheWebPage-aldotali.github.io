/**
 * Program name: IntBagIterator class Lab03 part b
 * Description: Creates an iterator class by using the iterator interface of java
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

import java.util.Iterator;

//public class IntBagIterator implements IntIterator 
//{
//    //properties
//    IntBag aBag;
//    int index;
//    
//    //constructor
//    public IntBagIterator (IntBag bag)
//    {
//        aBag = bag;
//        index = -1;
//    }
//    
//    //returns the next integer in the collection
//    public int nextInt()
//    {
//        index++;
//        return aBag.get(index);
//    }
//    
//    //returns the next value of the collection
//    public Integer next()
//    {
//        return nextInt();
//    }
//    
//    //checks whether the collection has a next value
//    public boolean hasNext()
//    {
//        return index < aBag.size() - 1;
//    }
//    
//    
//}