/**
 * Program name: IntIterator class Lab03 part b
 * Description: interface extending from javas's itersator interface
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */
import java.util.Iterator;

public interface IntIterator extends Iterator
{
    public int nextInt(); 
}