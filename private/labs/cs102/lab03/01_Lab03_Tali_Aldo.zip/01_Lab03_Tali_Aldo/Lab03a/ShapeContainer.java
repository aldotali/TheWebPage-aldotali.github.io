/**
 * Program name: Lab03a (2)
 * Description: Creates a class to contain a lot of shapes
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

import java.util.ArrayList;

public class ShapeContainer 
{
    //properties
    ArrayList<SelectableShape> shapes;
    
    //constructor
    public ShapeContainer ()
    {
        shapes = new ArrayList<SelectableShape>();
    }
    
    //adds a shape to the collection
    public void add(SelectableShape s)
    {
        shapes.add(s);
    }
    
    //returns the sum of the area of the shapes
    public double getArea()
    {
        //properties
        double sum;
        
        //initialization
        sum = 0;
        
        //calculates sum of areas of all shapes
        for (int i = 0; i < shapes.size(); i++)
        {
            sum = sum + (shapes.get(i)).getArea();
        }
        
        return sum;
    }
    
    //returns the String representation 
    public String toString()
    {
        //properties
        String s;
        
        s = "The total area is:" + getArea() + "\n";
        
        //gets the String representation of each shape
        for (int i = 0; i < shapes.size(); i++)
        {
            s = s + (shapes.get(i)).toString() + "\n";
        }
        
        return s;
    }
    
    //finds the first shape within the given coordinates
    public Shape findFirst(int x, int y)
    {
        int j;
        for (int i = 0; i < shapes.size(); i++)
        {
            if ((shapes.get(i)).shapecontains(x,y) != null )
            {
                (shapes.get(i)).setSelected(!(shapes.get(i)).getSelected());
                j = i;
                i = shapes.size();
                return shapes.get(j);   
            }
        }
        return null;
    }
    
    //removes the shape which is selected
    public void removeSelected ()
    {
        for (int i = 0; i < shapes.size(); i++)
        {
            if ((shapes.get(i)).getSelected())
            {
                shapes.remove(i);
                i--;
            }
        }
    }
    
    public Shape getV()
    {
        return shapes.get(shapes.size()-1);
    }
    
}


/*
 * (i) Does not compile as circle is not abstract anymore so there is no overriding method
 * (ii) the class now is abstract so it compiles
 * (ii) abstract method circle cannot be instansiated
 * */


/**
 * (i) comment out the getArea() method of the Circle class
 * Will not be allowed since it extends abstract class Shape, which contains getArea()
 */

/**
 * (ii) also make the Circle class abstract, before finally
 * Cannot do since we try to make and instane of it in ShapeTester class
 */

/**
 * (iii) creating an instance of the (now abstract) Circle class to add to the shapes collection.
 * Cannot do since cannot make instance of an abstract class
 */