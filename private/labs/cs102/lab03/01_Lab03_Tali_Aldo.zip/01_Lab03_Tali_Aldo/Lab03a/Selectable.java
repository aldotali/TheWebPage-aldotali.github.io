/**
 * Program name: Lab03a (4)
 * Description: Creates the Selectable interface
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

public interface Selectable
{  
    //returns wether the shape is selected
    public boolean getSelected();
    
    // sets the selected state of the shape
    public void  setSelected(boolean s);
    
    // checks if the shape contains the coordinates
    public Shape shapecontains( int x, int y);
}