/**
 * Program name: Lab03a (3) task
 * Description: Creates the Locatable interface to be used by the shapes
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

public interface Locatable
{
    // gets the location x and y of the shape
    public void setLocation(int x, int y);
    
    //returns the x coordinate of the shape
    public int getX();
    
    //returns the y coordinate of the shape
    public int getY();
    
}