/**
 * Program name: Lab03a (1)
 * Description: Creates Rectangle class of the hiearchy of shapes
 * @author Aldo Tali 21500097
 * version 1.00, 2016/03/01
 * */

public class Rectangle extends SelectableShape implements Selectable
{
    //properties
    int width;
    int height;
    boolean selected;
    
    //constructor
    public Rectangle (int width, int height)
    {
        super ();
        this.width = width;
        this.height = height;
        selected = false;
    }
    
    //returns the area
    public double getArea()
    {
        return (double) (height *width);
    }
    
    //returns the string representation
    public String toString()
    {
        return ("The area of the rectangle with sides : " + width + " and " + height + " is : " + getArea()
                    + "\n Is rectangle selected? " + getSelected());
    }
    
    //returns boolean if the shape contains the coordinates
    public Shape shapecontains( int x, int y)
    {
        if ((x-this.getX()) <= width  && y- this.getY() <= height)
        {
            return this;
        }
        return null;
    }
    
    //sets the value of selected
    public void setSelected(boolean s)
    {
        selected = s;
    }
    
    //returns wether the shape is selected or not
    public boolean getSelected()
    {
        return selected;
    }
    
}