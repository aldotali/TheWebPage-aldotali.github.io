//import java.util.Scanner;
//
///*
// * Progam name : Test Lab06b
// * Description : tests the countChar recurrsive method
// * @author : Aldo Tali 2150009
// * Version: 1.0;
// * 
// * */
//
//public class Testd2
//{
//    public static void main ( String[] args)
//    {
//        Scanner scan = new Scanner ( System.in);
//        
//        properties
//        int input;
//        Lab06d2 dummy;
//        
//        dummy = new Lab06d2();
//        
//        do
//        {
//        System.out.println("Please enter the number of digits");
//        input = scan.nextInt();
//        
//        dummy.evenNo(  input);
//        }while(input != -1);
//}
//}