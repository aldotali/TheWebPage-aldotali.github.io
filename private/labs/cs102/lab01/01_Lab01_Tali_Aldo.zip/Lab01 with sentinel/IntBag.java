import java.util.*;

/**
 * Program name: IntBag class Lab01
 * Description: This class creates a collection of integers
 * @author Aldo Tali 21500097
 * version 1.00, 2016/02/07
 * */

public class IntBag
{
    //constants
    public static final int Max_ELSE=100;
    
    //properties
    int[] bag;
    
    //no parameter constructor
    public IntBag()
    {   
        bag = new int[Max_ELSE + 1 ];    
        bag[0] = -1;
    }
    
    //constructor with max array length as parameter
    public IntBag(int max)
    {   
        bag = new int[max +1];
        bag[0] = -1;
    }
    
    //adds a value the collection
    public void add(int value)
    {
        if (size() >= bag.length -1)
        {
            System.out.println("You are exceeding your bounds!" + "\n The last value cannot be added to the collection" );
        }
        else
        {
           bag[size() + 1] = -1;
           bag[size()] = value;
        }
    }
    
    //adds a value at a specific index    
    public void add(int index, int value)
    {
        if (index >= size() || index > size() || size() >= bag.length - 1)
        {
            System.out.println("Sorry the index is out of bound or the array is already full");
        }
        else
        {
            int size;
            int temp = bag[index];
            
            size = size();
            bag[size + 1] = -1;
            bag[index] = value;
            
            
            //shifts values continiously to the right
            for(int i = index+1; i <= size ; i++)
            {
                value = bag[i];
                bag[i] = temp;
                temp = value;
            }
        }
    }
    
    //removes a value from the collection
    public void remove(int index)
    {
        if (index >= size())
        {
            System.out.println("Sorry the index is out of bound");
        }
        else
        {
            //continiously shift values to the left
            for(int i = index; i < size() -1; i++ )
            {
                bag[i] = bag[i+1];
            }
            bag[size() -1]=-1;
        }
    }
    
    //check if the bag contains the value
    public boolean contains (int value)
    {
        for (int i = 0; i < size(); i++)
        {
            if (bag[i] == value)
            {
                return true;
            }
        }
        return false;
    }
   
    // return the String representation of the array
    public String toString()
    {
        String  s = "[";
        for (int i = 0; i < size(); i++)
        {
            s = s + bag[i] + ",";
        }
        if (s.length()==1)
            return "[]";
        else
        return (s.substring(0,s.length()-1)+ "]");
    }
    
    // return the size of the collection
    public int size()
    {
       for (int i = 0 ; i < bag.length; i++)
       {
           if (bag[i] < 0)
               return i;
       }
       return bag.length;
    }
    
    //returns the number at the specific index
    public int get(int index)
    {
        return bag[index];
    }
    
    // finds the positions where a value is repeated
    public IntBag findAll(int value)
    {
      
        IntBag locations;
        locations = new IntBag(bag.length);
        
        for (int i = 0; i < size(); i++)
        {
            if ( bag[i] == value)
            {
                locations.add(i);
            }
        }
        return locations;
        
        
    }
}