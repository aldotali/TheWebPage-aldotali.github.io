import java.util.Scanner;

/**
 * Program name: Lab01c
 * Description: Runs a menu with options to updtate a collection of integers
 * @author Aldo Tali 21500097
 * version 1.00, 2016/02/07
 * */

public class Lab01c
{
    public static void main (String args[])
    {
        Scanner scan = new Scanner (System.in) ;
        
        //properties
        int input;
        int location;
        int max;
        int test;
        IntBag setNum;
        IntBag temp;
        boolean check8;
        
        //initialization
        setNum = new IntBag();
        temp = new IntBag(0);
        test = 0;
        max = -27;
        check8 = false;
        
        System.out.println("Welcome to the program");
        
        // run the game continiously until the user chooses not to
        do 
        {
            System.out.println("\n1.Create a new empty collection with a specified maximum capacity (any previous values are lost!)");
            System.out.println("2.Read a set of positive values into the collection (use zero to indicate all the values have been entered.)");
            System.out.println("3.Print the collection of values.");
            System.out.println("4.Add a value to the collection of values at a specified location");
            System.out.println("5.Remove the value at a specified location from the collection of values");
            System.out.println("6.Read a single test value.");
            System.out.println("7.Compute the set of locations of the test value within the collection* (see note below).");
            System.out.println("8.Print the set of locations.");
            System.out.println("9.Quit the program.");
            System.out.println();
            System.out.println();
            System.out.println(" Please enter your choice");
            
            input = scan.nextInt();
            
            if (input == 1)
            {
                System.out.println(" Please enter a specified maximum capacity : ");
                max = scan.nextInt();
                setNum = new IntBag(max);
            }
            
            else if ( input == 2)
            {
                if (max == -27)
                {
                    System.out.println("Sorry you haven't created a collection yet");
                }
                
                else
                {
                    System.out.println("Enter positive values (Any negative value won't be added to the collection)"
                                           + ": \n Enter 0 to stop adding");
                    max = scan.nextInt();
                    
                    while (max != 0)
                    {
                        if (max>=0)
                            setNum.add(max);
                        max = scan.nextInt();
                        
                    }
                }
            }
            
            else if (input == 3)
            {
                System.out.println("The collection of values is: " + setNum.toString());
            }
            
            else if (input == 4)
            {
                System.out.println("Please enter the value and the location");
                input = scan.nextInt();
                location = scan.nextInt();
                
                setNum.add(location , input);
                input = 4;
            }
            
            else if (input == 5)
            {
                System.out.println("Please enter the location of the value : ");
                input = scan.nextInt();
                
                setNum.remove(input);
            }
            
            else if (input == 6)
            {
                System.out.println("Please enter the test value : ");
                test = scan.nextInt();
                check8 =false;
            }
            
            else if (input == 7)
            {
                check8 = true;
                temp = setNum.findAll(test);
            }
            
            else if (input == 8 )
            {
                if (!check8)
                {
                    System.out.println("Sorry there is no test value or the locations may have not been computed yet");
                }
                
                else
                {    
                    System.out.println( "The locations of " + test + " are :" + temp.toString());
                }
            }
            else if (input == 9)
            {
                System.out.println("\nGoodbye!");
            }
            else
            {
                System.out.println("please enter a digit between 1 and 9 inclusive : "); 
            }
        }while (input != 9);
    }
}