import java.util.Scanner;

/**
 * Program name: Lab01b
 * Description: Prints the first 100 primes
 * @author Aldo Tali 21500097
 * version 1.00, 2016/02/07
 * */

public class Lab01b
{
    public static void main (String args[])
    {
        Scanner scan = new Scanner (System.in) ;
        
        // properties
        IntBag primes;
        int generate;
        boolean check;
        
        //initialization
        primes = new IntBag(100);
        primes.add(2);
        generate = 3;
        check = true;
        
        //run until it finds 100 primes
        do
        {
            //check whether a value is prime 
            for (int i = 0; i < primes.size(); i++ )
            {
                if (generate % primes.get(i) == 0)
                {
                    i = primes.size();
                    check = false;
                }
            }
            
            if (check)
            {
                primes.add(generate);
            }
            
            generate++;
            check = true;
            
        }while(primes.size()<100);
        
        System.out.println("These are the first 100 primes : \n");
        System.out.println(primes.toString());
        
    }
}