import java.util.Scanner;

/**
  * Program name: Lab06
  * Description: Program using methods
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/12
  * */
public class Lab06
   
{ 
  public static void main (String[] args)
  {
    Scanner scan = new Scanner (System.in) ;
    
    //test the methods
      double x,z;
    int y;
    String s,s1;
    /*x= scan.nextDouble();
    y= scan.nextInt();
    
    if (y <= 0)
    {
      System.out.println(" Non positive value of power.");
    }
    else
    {
      z= TheMethods.methodPower( x, y);
      System.out.println(z);
    }
    z= TheMethods.methodFactorial (y);
    System.out.println (z);
    s= scan.next();
    s1 = TheMethods.methodReverse (s);asd
    System.out.println(s1);
    s=scan.next();
    y= TheMethods.methodtoDecimal (s);
    System.out.println(y);
    y=scan.nextInt();
    s = TheMethods.methodtoBinary (y);
    System.out.println(s); 
    
     //excercise 1
    double n;
    int a=-1, b=10;
    for (int i=a; i<=b; i++)
    {
      
      for (int j= 1; j<5; j++)
      {
        n=TheMethods.methodPower (i,j);
        for (int k=0; k<(9 - (String.valueOf(n).length())); k++)
        {
          System.out.print(" ");
        }
        
        System.out.print (n);
        
      }
      System.out.println();
    }
    
    //excercise 2
    a=1;b=15;
    int c;
    for (int i=a; i<=b; i++)
    {
      
      for (int k=1; k<=b; k++ )
      {
        c=TheMethods.methodFactorial (k);
        
        for (int j=0; j< 15-(String.valueOf(c).length()+String.valueOf(i).length()); j++)
        {
          System.out.print (" ");
        }
        System.out.print (i + "," +TheMethods.methodFactorial (k));
      }
      System.out.println();
    }
    System.out.println();
    
    //excercise 3
    String a1,a2;
    a1=scan.next();
    a2=scan.next();
    a= TheMethods.methodtoDecimal (a1);
    b= TheMethods.methodtoDecimal (a2);
    c=a+b;
    System.out.println ( TheMethods.methodtoBinary(c));*/
    
    //excercise 4
    String a6= "";
    String a3;
    String a4 ="";
    String a5= " ";
    int i=1;
       
         a3= scan.nextLine();
         for (int h=0; h<a3.length(); h++)
         {
           if (a3.charAt(h) == a5.charAt(0))
           {
             a6 = a5 + a6;
             a4+= (TheMethods.methodReverse(a6));
             a6="";
           }
           else a6 += a3.charAt(h);
           
         }
                
       a4+= (TheMethods.methodReverse(a6));
    
     System.out.println (a4);
     
     //excercise 5
     final int fixed=10;
     double x1;
     double term=0;
     //double sum=0;
     x1=scan.nextInt();
     x1=Math.toRadians(x1);
     for (int o = 0; o <= fixed; o++)
     {    double sum=0;
         System.out.print("n is:"+ o);
         for (int k =0; k < 20- String.valueOf(o).length(); k++ )
         {
           System.out.print(" ");
         }
         
         System.out.print(" (-1)^n"+TheMethods.methodPower(-1,o));
         for (int h =0; h < 20- String.valueOf(TheMethods.methodPower(-1,o)).length(); h++ )
         {
           System.out.print(" ");
         }
         
         System.out.print("x^(2n+1)"+TheMethods.methodPower(x1,(2*o+1)));
         for (int g =0; g < 20- String.valueOf(TheMethods.methodPower(x1,(2*o+1))).length(); g++ )
         {
           System.out.print(" ");
         }
         
         System.out.print("(2n+1)-factorial "+ TheMethods.methodFactorial(2*o+1));
         for (int l =0; l < 20- String.valueOf(TheMethods.methodFactorial(2*o+1)).length(); l++ )
         {
           System.out.print(" ");
         }
         
         
         for (int m =0; m < o ; m++ )
         { 
           term = (TheMethods.methodPower(-1,m) * TheMethods.methodPower(x1,(2*m+1))/TheMethods.methodFactorial(2*m+1));
           sum =sum + term; 
           
         }
         System.out.print("term is : " +term);
         for (int p =0; p < 20- String.valueOf(term).length(); p++ )
         {
           System.out.print(" ");
         }
         System.out.print("sum is: " +sum);
            
           
       
       System.out.println();
     }
      //System.out.print("sum is: " +sum);
     
    

  }
}