import java.util.Scanner;


/**
  * Program name: Lab06
  * Description: Methods
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/12
  * */
  
public class TheMethods
   
{ 
  public static void main (String[] args)
  {}
    
    // method 1
    public static double methodPower( double x, int y)
    {
      double z = 1;
      for ( int i = 0 ; i < y; i++)
      {
        z *= x;
      }
      return z;
    }
    
    //method 2
    public static double methodFactorial ( int n)
    {
      int factorial = 1;
      for (int i = n; i > 0; i-- )
      {
        factorial *= i;
      }
      return factorial;
    }
    
    //method 3
    
   public static String methodReverse ( String s)
   {
     String p= "";
     for ( int i = s.length()-1; i > -1; i--)
     {
       p +=  s.charAt(i);
     }
     return p;
   }
   
   //method 4
   
   public static int methodtoDecimal (String base2)
   {
     int x;
     
     int p=1;
     String s= "";
     int z=0;
     
     for (int i=0 ; i<(base2.length()); i++)
     {
       s+=base2.charAt(i);
       x=Integer.valueOf(s);       
       for (int k=0; k<base2.length()-1-i; k++ )  
       {
         p*=2;
       }
        
       z += x*p;
          
       p=1;
       s= "";
     }
     
       return z;
   }
   
   public static String methodtoBinary (int x)
   {
     int z;
     String s="";
     
     for (int i=x; i>=0; i--)
     {
       z= x%2;
       s+=z;
       x=x/2;
       i=x;

     }
     return methodReverse (s);
    
   }
   
}
  
