/**
  * Program name: Lab09
  * Description: �mplement a Dice class to use two die objects and roll method
  * @author Aldo Tali 21500097
  * version 1.00, 2015/12/10
  * */

public class Dice 
{
    // Properties
     Die die1 = new Die() ;
     Die die2 = new Die() ;
        
    // Methods
    // Rolls the die
    public int rollsum()
    {
      return (die1.roll() + die2.roll());
      
    }
    
    // Face of the first die
    public int die1GetFaceValue()
    {
      return die1.getFaceValue();
    }
    
    // Face of the second die
    public int die2GetFaceValue()
    {
      return die2.getFaceValue();
    }
    
    // gets the sum
    public int getDiceTotal()
    {
      return die1.getFaceValue() + die2.getFaceValue();
    }

    // A toString of the first die
    public String toString()
    {
      return ("Die 1 : " + die1.getFaceValue() +" Die 2 : " + die2.getFaceValue());
    }
}    
