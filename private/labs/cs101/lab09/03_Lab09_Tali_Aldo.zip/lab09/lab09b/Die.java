/**
  * Program name: Lab09b
  * Description: Writing a class implementing methods to roll a die
  * @author Aldo Tali 21500097
  * version 1.00, 2015/12/10
  * */

public class Die 
{
    // Properties
     int rollDie;
    
    // Methods
    // Rolls the die
    public int roll()
    {
      rollDie = (int)(Math.random()*6) + 1;
      return rollDie;
    }
    
    // Gets the value of the face
    public int getFaceValue()
    {
      return rollDie;
    }

    // A toString
    public String toString()
    {
      return rollDie + "";
    } 
}