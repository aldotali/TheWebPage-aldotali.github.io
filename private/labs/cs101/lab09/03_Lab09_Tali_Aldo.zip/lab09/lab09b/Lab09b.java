import  java.util.Scanner;
import  java.util.ArrayList;

/**
  * Program name: Lab09b
  * Description: Create a graph with frequencies of sum of dices
  * @author Aldo Tali 21500097
  * version 1.00, 2015/12/10
  * */

public class Lab09b
{
  //The main method
  public static void main (String[] args)
  {
    Scanner scan = new Scanner (System.in);
    int nrOfThrows;
    
    System.out.println( " Please enter the number of times you want to roll the dice: ");
    nrOfThrows = scan.nextInt();
    System.out.println();
    graph(createData(nrOfThrows));
  }
  
    // Create the data to be used in the creation of the chart
    public static ArrayList<Integer> createData( int nrOfThrows )
    {
      // Constants
      final int LINES = 10;
      final int ZERO = 0;
      
      // Variables
      Dice pair;
      ArrayList<Integer> frequency;
      int peak;
      int range;
      
      pair = new Dice();
      peak = ZERO;
      frequency = new ArrayList<Integer>();
            
      //Initialize each of the frequencies
      for ( int i = 0; i < 11; i++)
      {
        frequency.add(ZERO);
      }
      
      // Throw the dice and determine the frequencies by storing them in the array
      for (int i=0; i < nrOfThrows; i++)
      {
        int value = pair.rollsum();
        frequency.set(value-2, (frequency.get(value-2) + 1));
      }
      
      // Determine which number is highest in the frequency
      for ( int i = 0; i < 11; i++)
      {
        if ( frequency.get(i) > peak )
        {
          peak = frequency.get(i);
        }
      }
      
      //Compute the range which determines when the stars will be printed
      range = peak/LINES;
      
      //Determine the number of stars for each number
      for ( int i = 0 ; i < 11 ; i++ ) 
      {
        frequency.set(i, frequency.get(i)/range );
      }
      
      System.out.println (" Peak: " + peak +"\n The frequency is : " + frequency );
      
      return frequency;
           
    }
      
    //Create method to print stars and spaces
    public static void graph ( ArrayList<Integer> frequency)
    {
      //Constants
      final int LINES = 10;
      
      //Run the loop to print stars and spaces 
      for ( int i = LINES; i > 0; i-- )
      {
        for ( int j = 0; j < 11; j++ )
        {
          if ( frequency.get(j) >= i)
          {
            System.out.print("*");
          }
          else
          {
            System.out.print(" ");
          }
        }
        System.out.println();
      }
      
    }
}
  