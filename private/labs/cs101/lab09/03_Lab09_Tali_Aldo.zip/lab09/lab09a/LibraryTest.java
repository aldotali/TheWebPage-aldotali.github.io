import java.util.Scanner;

/**
  * Program name: Lab09a 
  * Description: Testing the Library class 
  * @author Aldo Tali 21500097
  * version 1.00, 2015/12/03
  * */

public class LibraryTest
{
  public static void main ( String [] args )
  {
    Scanner scan = new Scanner (System.in);
    String input;
    String input2;
    String input3;
    Library p;
    LibraryBook b;
    
    p = new Library ();
    
    //run a menu at least once
    do
    {
      System.out.println( " Welcome to the menu! ");
      System.out.println( " Please choose one of the following: ");
      System.out.println( " Show, Find, Add, Exit ");
      
      //user enters an option from the menu
      input = scan.next();
      
      //check the input to determine the option selected
      if ( input.equals("Show") )
      {
        System.out.println(p.toString());
      }
      else if( input.equals("Find"))
      {
        System.out.println( " Please enter the title of the book: ");
        //Get the title of the book
        input2 = scan.next();
        // run the find title method and save the book which is found on b
        b = p.findByTitle(input2);
        
        //when there is no book print prompt message
        if (b==null)
        {
          System.out.println("Sorry we do not have such a book");
        }
        
        else
        {
          do 
          {
            //print the menu
            System.out.println(" Choose one of the following: ");
            System.out.println(" Loan, Return, Remove, Menu ");
            input3 = scan.next();
            
            //choose which action to take depending on the input
            if (input3.equals("Remove"))
            {
              //run the remove method
              p.remove(b);
            }
            else if (input3.equals("Loan"))
            {
              //run the onloan method and print message
              System.out.println ("The book to string \t" + b.toString()+ "\t is it on loan? \t" + b.onloan() + "\t times loaned: \t" +b.getTimesLoaned());
            }
            else if (input3.equals("Return"))
            {
              //run the return method
              b.returnbook();
              System.out.println ( " The book is returned \t" + b.toString());
            }
            
            //prompt error message for unknown input
            else
            {
              if (!(input3.equals("Menu")))
              {
                System.out.println("Wrong input");
              }
            }
            
          }while(!(input3.equals("Menu")));
        }
      }
      else if ( input.equals("Add"))
      {
        System.out.println( "Please enter the title and the author");
        input2 = scan.next();
        input3 = scan.next();
        //run the add method
        p.add(input2,input3);
      }
      else
      { 
        if(!(input.equals("Exit")))
        System.out.println( " Incorrect input ");
      }
    }while ( !(input.equals("Exit")));
  }
 

    
  }
