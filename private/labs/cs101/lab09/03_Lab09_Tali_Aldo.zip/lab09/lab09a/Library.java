import java.util.ArrayList;
/**
 * Program name: Lab09a 
 * Description: Creates instance methods using arrays
 * @author Aldo Tali 21500097
 * version 1.00, 2015/12/10
 * */

public class Library
{
  
  //Properties
 
  ArrayList<LibraryBook> books;
  String S = "";
  int j = 1;
  int k;
  
  public Library ()
  {
    books = new ArrayList<LibraryBook>();
  }
  
  //return true if there are no books
  public boolean isEmpty()
  {
  return ( books.size() == 0 );
  }
  
  // print the books as strings
  public String toString ()
  {
    S= "";
    for (int i = 0; i < books.size(); i++)
    {
      S = S + " The " + (i+1) + " book is : " + books.get(i) + "\n";   
    }
     return  S;
  }
  
  // add a new book
  public void add ( String title , String author)
  {
     books.add((new LibraryBook(title , author , " 25-December ", 3)));
  }
  
  //removes the book from the library
  public void remove ( LibraryBook book )
  {
    for (int i=0; i < books.size(); i++)
    {
      if ( books.get(i) != null && book.equals(books.get(i)))
      {
        books.remove(i);
        i = books.size();
        j= 6;
      }
    }
    if (j != 6)
    {
      System.out.println( " Sorry the book is not on the library :/ ");
    }
  }
  
    //finds a book by its title
  public LibraryBook findByTitle( String title )
  {
    LibraryBook b5;
    b5 =  new LibraryBook(title , "Aldo" , " 25-December ", 3);
    for (int i = 0; i < books.size(); i++)
    {
      if (books.get(i)!= null && books.get(i).hasSameTitle(b5))
      {
        System.out.println(" The " + (i+1) + " book : \t" + books.get(i) );
        k = i;
        i = books.size();
        j = 7;
      }
    }
    if (j == 7)
    {
      return books.get(k);
    }
    else
      return null;
  }
  

}