/**
 * Program name: Lab09a 
 * Description: Create a class LibraryBook with different methods
 * @author Aldo Tali 21500097
 * version 1.00, 2015/12/10
 * */


public class LibraryBook
{
  
  // Properties
  String title;
  String author;
  String dueDate;
  int timesLoaned;
  String dummy =" ";
  
  //Constructors
  public LibraryBook (String thetitle,String theauthor,String thedueDate,int thetimesLoaned)
  {
    title = thetitle;
    author = theauthor;
    dueDate = thedueDate;
    timesLoaned = thetimesLoaned;
  }
  
  //copy constructor
  public LibraryBook (LibraryBook other)
  {
    this.title = other.title ;
    this.author = other.author;
    this.dueDate = other.dueDate;
    this.timesLoaned = other.timesLoaned;
  }
  
  //Methods
  //determine wether the book is on loan already
  public boolean onloan()
  {
    if ( dummy.length() > 0 )
    {
      timesLoaned++;
      dummy = "";
      return false;
    }
    else if (dummy == "")
    {
      
      return true;
      
    }
    else return false;
  }
  
  //return the book when the user needs to
  public void returnbook()
  {
    dummy = " ";
  }
  
  //number of times the book is loaned
  public int getTimesLoaned()
  {
    return timesLoaned;
  }
  
  //get the string
  public String toString()
  {
    return (title + " " + author + " " + dueDate + " " + timesLoaned); 
  }
  
  //equals method
  public boolean equals (LibraryBook book)
  {
    return book != null 
         && title == book.title
         && author == book.author;
  }
  
  
  //hasSametitle
  public boolean hasSameTitle ( LibraryBook book )
  {
    return (this.title.equals(book.title) && this.title != null);
  }
  
  
  //hasSameAuthor
  public boolean hasSameAuthor ( LibraryBook book )
  {
    return (this.author.equals(book.author) && this.author != null);
  }
}