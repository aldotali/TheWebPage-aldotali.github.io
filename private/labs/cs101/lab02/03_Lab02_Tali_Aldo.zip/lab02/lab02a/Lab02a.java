// ************************************
// **** simple console application ****
// ************************************

import java.util.Scanner;

/**
 *  
 * Lab02c 
 * @author Aldo Tali 21500097
 * @version 
 */ 
public class Lab02a
{
    public static void main( String[] args)
    {
        Scanner scan = new Scanner( System.in);
        
        // constants
        
        // variables
        
        // program code
        System.out.println ( "Start...");

        // todo...
        
        System.out.println ( "End.");
    }
    
}