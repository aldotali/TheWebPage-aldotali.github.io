/**
  * Program name: Lab08 
  * Description: Cases to test LibraryBook
  * @author Aldo Tali 21500097
  * version 1.00, 2015/12/03
  * */

public class TestLibraryBook
{
  public static void main (String [] args)
  {
    //variables
    LibraryBook book1;
    LibraryBook book2;
    LibraryBook book3;
    LibraryBook bookd;
    
    //assign values to each book object in the Librarybook
    book1 = new LibraryBook ("ALDO","REDI","26-NOVEMBER",3);
    book2 = new LibraryBook ("ALDO","BEDRIU","03-DECEMBER",3);
    book3 = new LibraryBook ("ALDO","REDI","26-NOVEMBER",3);
    
    //check the " == " and " .equals " when comparing
    System.out.println ( " book1 (ALDO,REDI,26-NOVEMBER,3) == book1 (ALDO,REDI,26-NOVEMBER,3) \t" + ( book1 == book1 ));
    System.out.println ( " book1.equals(book1) \t" + book1.equals(book1));
    
    System.out.println ( " book1 (ALDO,REDI,26-NOVEMBER,3) == book3 (ALDO,REDI,26-NOVEMBER,3) \t" + ( book1 == book3 ));
    System.out.println ( " book1.equals(book3) \t" + book1.equals(book3));
    
    System.out.println ( " book1 (ALDO,REDI,26-NOVEMBER,3) == book2 (ALDO,BEDRIU,03-DECEMBER,3) \t" + ( book1 == book2 ));
    System.out.println ( " book1.equals(book2) \t" + book1.equals(book2));
    System.out.println();
    System.out.println();
    
    //check the hasSametitle and hasSameAuthor
    System.out.println ( " Do the first and the second book have the same author? \t" + book1.hasSameAuthor( book2 ) );
    System.out.println ( " Do the first and the third book have the same author? \t" + book1.hasSameAuthor( book3 ) );
    System.out.println ( " Do the first and the second book have the same title? \t" + book1.hasSameTitle( book2) );
    System.out.println ( " Do the first and the third book have the same title? \t" + book1.hasSameTitle( book3) );
    
    //check the copy constructor
    bookd = new LibraryBook(book1);
    System.out.println ( " The copy of the first book: \t" + bookd.toString());
    
    System.out.println();
    System.out.println();
    
    //display the books
    System.out.println ("The book to string \t" + book1.toString()+ "\t is it on loan? \t" + book1.onloan() + "\t times loaned: \t" +book1.getTimesLoaned());
    System.out.println ("The book to string \t" + book1.toString()+ "\t is it on loan? \t" + book1.onloan() + "\t times loaned: \t" +book1.getTimesLoaned());
    
    //return the book
    System.out.println ( " The book is returned ");
    book1.returnbook();
  
    //display the books
    System.out.println ("The book to string \t" + book1.toString()+ "\t is it on loan? \t" + book1.onloan() + "\t times loaned: \t" +book1.getTimesLoaned());
    System.out.println ("The book to string \t" + book2.toString()+ "\t is it on loan? \t" + book2.onloan() + "\t times loaned: \t" +book2.getTimesLoaned());
  }
}