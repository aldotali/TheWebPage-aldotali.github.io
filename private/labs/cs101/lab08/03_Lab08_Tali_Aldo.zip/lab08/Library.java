/**
 * Program name: Lab08 
 * Description: Creates instance methods
 * @author Aldo Tali 21500097
 * version 1.00, 2015/11/26
 * */

public class Library
{
  
  //Properties
  LibraryBook b1;
  LibraryBook b2;
  LibraryBook b3;
  LibraryBook b4;
  LibraryBook b5;
  
  public Library ()
  {
    b1 = null;
    b2 = null;
    b3 = null;
    b4 = null;
  }
  
  //return true if there are no books
  public boolean isEmpty()
  {
    return (     b1 == null 
              && b2 == null
              && b3 == null
              && b4 == null );
  }
  
  // print the books as strings
  public String toString ()
  {
    return (" The first book : \t" + b1 + "\n" +
            " The second book : \t" + b2 + "\n" +
            " The third book : \t" + b3  +"\n" +
            " The fourth book : \t" + b4 + "\n");
  }
  
  // add a new book
  public void add ( String title , String author)
  {
    // assign a new book to the first non null book
    if ( b1 == null)
    {
      b1 =  new LibraryBook(title , author , " 25-December ", 3);
      System.out.println (" The first book is: " + b1);
    }
    else if ( b2 == null)
    {
      b2 =  new LibraryBook(title , author , " 25-December ", 3);
      System.out.println (" The second book is: " + b2);
    }
    else if ( b3 == null)
    {
      b3 =  new LibraryBook(title , author , " 25-December ", 3);
      System.out.println (" The third book is: " + b3);
    }
    else if ( b4 == null)
    {
      b4 =  new LibraryBook(title , author , " 25-December ", 3);
      System.out.println (" The fourth book is: " + b4);
    }
    else
    {
      System.out.println( " Sorry there is no more book space :/ ");
    }
  }
  
  //removes the book from the library
  public void remove ( LibraryBook book )
  {
    if (b1!=null &&  book.equals(b1))
    {
      b1 = null;
    }
    else if (b2!=null && book.equals(b2))
    {
      b2 = null;
    }
    else if (b3!=null && book.equals(b3))
    {
      b3 = null;
    }
    else if (b4!=null && book.equals(b4))
    {
      b4 = null;
    }
    else
    {
      System.out.println( " Sorry the book is not on the library :/ ");
    }
  }
  
    //finds a book by its title
  public LibraryBook findByTitle( String title )
  {
    
    b5 =  new LibraryBook(title , "Aldo" , " 25-December ", 3); 
    if (b1!=null && b1.hasSameTitle(b5))
    {
      System.out.println(" The first book : \t" + b1 );
      return b1;
    }
    else if ( b2!=null && b2.hasSameTitle(b5))
    {
      System.out.println(" The second book: \t" + b2);
      return b2;
    }
    else if ( b3!=null && b3.hasSameTitle(b5))
    {
      System.out.println(" The third book \t" + b3);
      return b3;
    }
    else if (b4!=null && b4.hasSameTitle(b5))
    {
      System.out.println(" The fourth book: \t" + b4);
      return b4;
    }
    else return null;
  }
  

}