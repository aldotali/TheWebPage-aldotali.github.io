/**
  * Program name: Lab07b 
  * Description: A class, LibraryBook, that  represents an individual book that can be borrowed from the library
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */
public class LibraryBook 
{
  //-----Properties----------------------------------------------------------------------------------------------------
  String title;
  String author;
  String dueDate;
  String newDueDate;
  int timesLoaned;
  
  //----Constructors---------------------------------------------------------------------------------------------------
  public LibraryBook( String title, String author, String dueDate, int timesLoaned) 
  {
   this.title = title;
   this.author = author;
   this.dueDate = dueDate;
   this.timesLoaned = timesLoaned;
  }

  // Methods
  // -----Display the book---------------------------------------------------------------------------------------------
  public String toString()
  {
     return "Book : \"" + title + "\", " + "Author : \"" + author + 
            "\", " + "New due date : \"" + dueDate + "\", " +"Times loaned : \"" + timesLoaned + "\"."; 
  }
  
  //-----Loan the book-------------------------------------------------------------------------------------------------
  public void toLoan(String newDueDate)
  {  
    if ( !(onLoan()))
    {
      timesLoaned = timesLoaned + 1;
      dueDate = newDueDate;
    }
     else
     {
       System.out.println( " Book not available" );
     }
   
  }
   
  //-----Return the book-----------------------------------------------------------------------------------------------
  public void returnBook()
  {  
     dueDate = "";
    
  }
    
  //-----Times loaned--------------------------------------------------------------------------------------------------
  public int getTimesLoaned()
  {  
   return timesLoaned ;
  }
  
   //-----On loan or not-----------------------------------------------------------------------------------------------
  public boolean onLoan()
  {  
   if(dueDate.length() > 0)
   {
      return true;
   }
   else
   {
      return false;
   }
  }
    
}