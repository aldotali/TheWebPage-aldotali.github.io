/**
  * Program name: Lab07b 
  * Description: Test LibraryBook
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */
public class TestLibraryBook
{
  public static void main(String[] args)
  {
    // Variables
    LibraryBook firstBook;
    LibraryBook secondBook;
    LibraryBook thirdBook;
    
    // Program code
    firstBook = new LibraryBook("Shrek", "Fiqo", "30 November", 1);
    secondBook = new LibraryBook("Shrek", "Fiqo", "30 November", 1);
    thirdBook = new LibraryBook("Broken April", "Ismail Kadare", "28 November", 1);
     
    // Display of the books
    System.out.println("First book : " + firstBook.toString());
    System.out.println("Second book : " + secondBook.toString());
    System.out.println("Third book : " + thirdBook.toString());
    
    // Loan a book
    firstBook.toLoan("1 December");
    
    // Return a book
    firstBook.returnBook();
    
    //Times loaned
    System.out.println("number of loans: " + firstBook.getTimesLoaned());
    
    // On loan or not
    System.out.println("is loaned?: " + firstBook.onLoan());
    
     // Loan a book
    secondBook.toLoan("1 December");
    
    // Return a book
    secondBook.returnBook();
    
    //Times loaned
    System.out.println("number of loans: " + secondBook.getTimesLoaned());
    
    // On loan or not
    System.out.println("is loaned?: " + secondBook.onLoan());
  }
}