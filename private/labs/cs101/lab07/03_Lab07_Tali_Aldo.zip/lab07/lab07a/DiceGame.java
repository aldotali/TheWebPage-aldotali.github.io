/**
  * Program name: Lab07a part 5
  * Description: Create a game by using classes
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */

public class DiceGame
{
    // Properties
    Dice rollDice = new Dice();
  
    // Methods
    
    // Play
    public int play()
    {
      int count = 0;
      while(rollDice.rollsum() != 12)
      {
        count = count + 1;
      }
      return count;
    }
}