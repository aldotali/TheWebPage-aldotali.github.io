/**
  * Program name: Lab07a part 5
  * Description: Test the dice game
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */
public class TestDiceGame
{
  public static void main(String[] args)
  {
    // Variables
    DiceGame firstGame;

    // Program code
    firstGame = new DiceGame();
    
    // Roll the ices until we have to six
    System.out.println( "Lets roll the dices " );
    System.out.println( "Number of rolls before two 6 : " + firstGame.play() ); 
  }
}
  