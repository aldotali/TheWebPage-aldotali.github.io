import java.util.Scanner;

/**
  * Program name: Lab07a part 1 & 2
  * Description: Program generat�ng dice using methods the old way
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */

public class Lab07a
{
  public static void main(String[] args)
  {
    // The old way by  methods
    
    // Constants
    final int FACE_NO = 6;
    final int ONE = 1;
    final int NO_OF_PAIRS = 10;
    final int SUM = 12;
    final int ZERO = 0;
    
    // Variables
    int firstDie;
    int secondDie;
   
    
    for(int n = ZERO ; n < NO_OF_PAIRS ; n++) 
    {
      int count = ZERO;
      
      // Stops when two sixs are thrown
      do
      {
        // Generates the first die
        firstDie = (int)(Math.random()*FACE_NO) + ONE;
        
        // Generates second die
        secondDie = (int)(Math.random()*FACE_NO) + ONE;
        
        // Counts the rolls
        count= count + ONE;
      }while ( firstDie + secondDie < SUM );
      
      // Prints the mumber of rolls and the number of each dice
      System.out.println( " The dice are thrown : " + count + " times. " );// + " Dice 1 : " + firstDie + " Dice 2 : " + secondDie );
      /*to extend this into a program which stimulates more than one rolling
       * we can put this into a method and use a for loop after this
       */
    }
  }
}