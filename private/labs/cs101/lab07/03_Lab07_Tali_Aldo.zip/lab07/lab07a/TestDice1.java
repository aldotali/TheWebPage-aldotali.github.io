/**
  * Program name: Lab07a part 4
  * Description: To test the implementation of the Dice 
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */
public class TestDice1
{
  public static void main(String[] args)
  {
    // Variables
    Dice oneRoll;

    // Program code
    oneRoll = new Dice();
    
    // Dices are rolled together
    System.out.println( "Lets roll the dices");
    System.out.println("Sum of the dices is : " + oneRoll. rollsum()) ;
    
    
    // Gives the current value of the die
    System.out.println( "The current faces of the dices");
    System.out.println("Die one : " + oneRoll.getFaceValue1());
    System.out.println("Die one : " + oneRoll.getFaceValue2());
    
    // Give the total of Dices
    System.out.println( "The total of dice is");
    System.out.println(oneRoll.getDiceTotal());
    
   
    // Gives the values of the dices as string
    System.out.println( "dices as astring");
    System.out.println(oneRoll.toString());
    
    
  }
}
  
