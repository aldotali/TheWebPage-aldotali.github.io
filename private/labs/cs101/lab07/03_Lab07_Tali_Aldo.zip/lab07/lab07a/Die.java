/**
  * Program name: Lab07a part 3
  * Description: Writing a class implementing methods
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */
public class Die 
{
    // Properties
     int rollDie;
    
    // Methods
    // Rolls the die
    public int roll()
    {
      rollDie = (int)(Math.random()*6) + 1;
      return rollDie;
    }
    
    // Gets the value of the face
    public int getFaceValue()
    {
      return rollDie;
    }

    // A toString
    public String toString()
    {
      return rollDie + "";
    } 
}