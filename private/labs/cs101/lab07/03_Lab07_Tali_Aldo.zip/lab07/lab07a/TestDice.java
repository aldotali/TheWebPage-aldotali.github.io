/**
  * Program name: Lab07a part 4
  * Description: To test the implementation of the Dice 
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */
public class TestDice
{
  public static void main(String[] args)
  {
    // Variables
    Dice oneRoll;

    // Program code
    oneRoll = new Dice();
    
    // Dices are rolled together
    System.out.println( "Lets roll the dices");
    System.out.println("Sum of the dices is : " + oneRoll. rollsum()) ;
    
    
    // Gives the current value of the die
    System.out.println( "The current faces of the dices");
    System.out.println("Die one : " + oneRoll.getFaceValue1());
    System.out.println("Die one : " + oneRoll.getFaceValue2());
    
    // Give the total of Dices
    System.out.print( "The total sum of the dice is ");
    System.out.println(oneRoll.getDiceTotal());
    
   
    // Gives the values of the dices as string
    System.out.print( "Dices as astring ");
    System.out.println(oneRoll.toString());
    
    
  }
}
  
