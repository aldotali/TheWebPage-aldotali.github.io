/**
  * Program name: Lab07a part 3
  * Description: Testing the die class
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */
public class TestDie
{
  public static void main(String[] args)
  {
    // Variables
    Die firstDie;
    Die secondDie;
    
    // Program code
    firstDie = new Die();
    secondDie = new Die();
    
    // Dice are rolled
    System.out.println( "Lets roll the dices");
    System.out.println( "The first die face " + firstDie.roll() );
    System.out.println( "The first die face " + secondDie.roll());
    
    // Gives the current value of the die
    System.out.println( "The current faces of the dices");
    System.out.println("The first die face " + firstDie.getFaceValue());
    System.out.println("The first die face " + secondDie.getFaceValue());
   
    // Gives the values of the dices as string
    System.out.println( "dices as a string");
    System.out.println("The first die face " + firstDie.toString());
    System.out.println("The first die face "  + secondDie.toString());
    
  }
}