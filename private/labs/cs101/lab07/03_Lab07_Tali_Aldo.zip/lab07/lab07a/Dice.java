/**
  * Program name: Lab07a part 4
  * Description: �mplement a Dice class to use two die objects and roll method
  * @author Aldo Tali 21500097
  * version 1.00, 2015/11/26
  * */

public class Dice 
{
    // Properties
     Die firstDie = new Die() ;
     Die secondDie = new Die() ;
        
    // Methods
    // Rolls the die
    public int rollsum()
    {
      return (firstDie.roll() + secondDie.roll());
      
    }
    
    // Face of the first die
    public int getFaceValue1()
    {
      return firstDie.getFaceValue();
    }
    
    // Face of the second die
    public int getFaceValue2()
    {
      return secondDie.getFaceValue();
    }
    
    // gets the sum
    public int getDiceTotal()
    {
      return secondDie.getFaceValue() + firstDie.getFaceValue();
    }

    // A toString of the first die
    public String toString()
    {
      return (secondDie.getFaceValue() + firstDie.getFaceValue())+ "";
    }
}    
